import java.util.*;
public class Perfect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter a value");
		int n=s.nextInt();
		int p=0;
		System.out.println("factors of "+n);
		for(int i=1;i<=n/2; i++)
		{
			if(n%i==0)
			{
				System.out.print(i+"  ");
				p=p+i;
			}
		}
		if(p==n)
			System.out.println("\n perfect no "+n);
		else
			System.out.println(" \n not a perfect no "+n);
	}
}
