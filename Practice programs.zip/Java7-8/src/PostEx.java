//post ++ example
public class PostEx {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		System.out.println("POST ++ ");
		System.out.println("a = "+a);
		System.out.println("a ++ ="+(a++));
		System.out.println("a = "+a);
		a=50;
		System.out.println("Pre ++ ");
		System.out.println("a = "+a);
		System.out.println(" ++ a ="+(++a));
		System.out.println("a = "+a);

	}

}
