//conditional operator example
import java.util.*;
public class CondOper {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int a,b;
		System.out.println("enter 2 nos ");
		a=s.nextInt();
		b=s.nextInt();
		System.out.println("a = "+a+"   b = "+b);
		//checking bigger no
		
		int big=(a>b) ? a : b;
		System.out.println("bigger no ="+big);
		
	}

}
