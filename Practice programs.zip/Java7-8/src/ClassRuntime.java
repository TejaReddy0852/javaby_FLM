import java.util.*;
class Emp
{
	int eno;
	String ename;
	double sal;
	void read(int no,String n,double s)
	{
		System.out.println("reading Emp values");
		eno=no;
		ename=n;
		sal=s;
	}
	void output()	
	{
		System.out.println("\t\tEMPLOYEE PAY SLIP");
		System.out.println("EMP NO ="+eno+ "\t\t EMP NAME ="+ename);
		System.out.println("BASIC SALARY ="+sal);
		double netsal=sal+sal*30/100;
		System.out.println("NET SALARY ="+netsal);
	}
}
public class ClassRuntime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		//creating obj for Emp
		Emp e=new Emp();
		//accepting values at runtime
		System.out.println("enter emp no,name and salary");
		int tno=sc.nextInt();
		String s=sc.next();
		double d=sc.nextDouble();
		//passing variables to Emp class
		e.read(tno, s, d);
		e.output();
		}

}
