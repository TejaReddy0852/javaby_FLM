import java.util.*;
public class SwitchMenu {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("\t\t\tArithmatic Operations");
		System.out.println("1.Add\n 2.Sub\n 3.Mul\n4.Reminder");
		System.out.println("Enter your choice(1/2/3/4) ");
		int choice=s.nextInt();
		if(choice<=4)
		{
			System.out.println("enter 2 nos ");
			int a=s.nextInt();
			int b=s.nextInt();
			switch(choice)
			{
			case 1:
					System.out.println("addition = \t"+(a+b));
					break;
			case 2:
					System.out.println("Subtraction ="+(a-b));
					
			case 3:
					System.out.println("Multiplication ="+(a*b));
					break;
			case 4:
					System.out.println("Reminder ="+(a%b));
					break;
			
			}
		}
		else
			System.out.println("Wrong Choice...");
}
}