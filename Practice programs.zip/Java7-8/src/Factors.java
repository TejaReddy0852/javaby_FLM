//factors of a given no
import java.util.*;
public class Factors {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter a no ");
		int n=s.nextInt();
		System.out.println("Factors of "+n);
		int i=1;
		while(i<=n)
		{
			if(n%i==0)
				System.out.print(i+"  ");
			i++;
		}
	}

}
