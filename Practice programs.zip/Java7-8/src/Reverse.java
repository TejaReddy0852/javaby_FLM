import java.util.*;
public class Reverse {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int n,rev=0,rem=0;
		System.out.println("enter a no");
		n=s.nextInt();
		while(n>0)
		{
			rem=n%10;
			rev=rev*10+rem;
			n=n/10;
		}
		System.out.println("reverse of the no ="+rev);
	}

}
