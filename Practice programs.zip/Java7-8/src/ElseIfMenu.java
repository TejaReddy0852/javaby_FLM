import java.util.*;
public class ElseIfMenu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("\t\tArithmatic Operations");
		System.out.println("1.Add");
		System.out.println("2.Sub");
		System.out.println("3.Mul");
		System.out.println("4.Reminder");
		System.out.println("Enter your choice(1/2/3/4) ");
		int choice=s.nextInt();
		if(choice<=4)
		{
			System.out.println("enter 2 nos ");
			int a=s.nextInt();
			int b=s.nextInt();
		
		if(choice==1)
			System.out.println("addition ="+(a+b));
		else if(choice==2)
			System.out.println("Subtraction ="+(a-b));
		else if(choice==3)
			System.out.println("Multiplication ="+(a*b));
		else 
			System.out.println("Reminder ="+(a%b));
		}
		else
			System.out.println("Wrong Choice...");
	
	}
	

}
