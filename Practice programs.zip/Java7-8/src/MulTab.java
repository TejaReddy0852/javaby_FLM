//wap to accept a no and print multiplication table
import java.util.*;
public class MulTab {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter a no");
		int n=s.nextInt();
		System.out.println("Multiplication table of "+n);
		for(int i=1;i<=10 ;i++ )
		{
			System.out.println(n+ "   X  " +i+ "    =  "+n*i);
		}
	}
}
