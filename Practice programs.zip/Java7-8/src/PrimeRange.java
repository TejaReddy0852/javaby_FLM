import java.util.*;
public class PrimeRange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter min and max values");
		int m=s.nextInt();
		int n=s.nextInt();
		System.out.println("Prime nos between "+m+" and "+n );
		
		for( ; m<=n ;m++)  //m for min value
		{
			int count=0;
			for(int i=1;i<=m/2;i++)
			{
				if(m%i==0)
					count++;
			}
			if(count==1)
				System.out.println(m);
		}

	}

}
