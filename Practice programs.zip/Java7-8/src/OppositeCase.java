import java.util.*;
public class OppositeCase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter an alphabet");
		char c=s.next().charAt(0);
		int a;
		if(c>=65 && c<=90) 	//if(c>='A' && c<='Z')
			a=c+32;
		else
			a=c-32;
		c=(char)a;	//type casting
		System.out.println("alphabet in opposite case "+c);
	}

}
