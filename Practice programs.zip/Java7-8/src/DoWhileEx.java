public class DoWhileEx {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("printing 1..10");
		int a=11;
		do
		{
			System.out.println(a);
			a++;
		}while(a<=10);
	}
}
