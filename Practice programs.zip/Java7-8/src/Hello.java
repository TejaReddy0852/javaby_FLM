
public class Hello {

	public static void main(String[] args) {
		int a=20;
		int b=500;
		int x=a*b;
		System.out.println("product of 2 nos ="+x);
		}
}
