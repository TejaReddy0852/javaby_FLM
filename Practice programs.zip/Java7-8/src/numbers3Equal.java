//read 3 nos and check 3 are equal or not
import java.util.Scanner;
public class numbers3Equal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter 1st no");
		int x=s.nextInt();
		System.out.println("enter 2nd no");
		int y=s.nextInt();
		System.out.println("enter 3rd no");
		int z=s.nextInt();
		
		if(x==y && x==z)
			System.out.println("3 are equal");
		else
			System.out.println("3 are not equal");
	}

}
