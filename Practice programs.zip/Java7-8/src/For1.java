public class For1 {
	public static void main(String[] args) {
	System.out.println("printing 1 to 10 nos");
	int i=1;
	for(; ;	)
	{
		System.out.println(i);
		if(i==10)
			break;
		i++;
	}
}
}