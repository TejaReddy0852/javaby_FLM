import java.util.*;
public class Digitornot {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter a digit");
		char c=s.next().charAt(0);
		if(c>=48 && c<=57)
			System.out.println(c+" is a digit");
		else
			System.out.println(c+" is not a digit");
	}

}
