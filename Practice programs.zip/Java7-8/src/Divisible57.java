import java.util.Scanner;
public class Divisible57 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter a no");
		int n=s.nextInt();
		if(n%5==0 && n%7==0)
			System.out.println(n+ " is divisible by 5,7");
		else
			System.out.println(n+ " is not divisible by 5,7");
	}

}
