//student report
import java.util.Scanner;
public class ScannerEx {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter student no ");
		int no=s.nextInt();
		System.out.println("enter student name ");
		String name=s.next();
		System.out.println("enter student marks in 3 subjects ");
		int m1=s.nextInt();
		int m2=s.nextInt();
		int m3=s.nextInt();
		//calculating total and avg
		int tot=m1+m2+m3;
		
		double avg=(double)tot/3;//parsing to double
		System.out.println("Student Details");
		System.out.println("NO ="+no+" \t NAME = "+name);
		System.out.println("TOTAL MARKS ="+tot);
		System.out.println("Avg MARKS ="+avg);
	}

}
