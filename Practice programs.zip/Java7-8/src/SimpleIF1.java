//number is positive or not
import java.util.*;
 class SimpleIF1 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter a no ");
		int a=s.nextInt();
			
		//checking the no is +ve or not
		if(a>0)
		{
			System.out.println(a+ " is a Positive no");
		}
		System.out.println("END");
	}
}