
public class Odd100to50 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=200;
		System.out.println("printing 100 to 50 odd nos");
		while(a<=300)
		{
			System.out.print(a+"    ");
			a+=5;
		}
	}

}
