import java.util.*;
public class ElseifStudent {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter sno,name of the student");
		int sno=s.nextInt();
		String name=s.next();	
		System.out.println("enter marks in 3 subjects ");
		int m1=s.nextInt();
		int m2=s.nextInt();
		int m3=s.nextInt();
		char grade;
		int tot=0;
		double avg=0;
		if(m1>=40 && m2>=40 && m3>=40)
		{
			 tot=m1+m2+m3;
			 avg=(double)tot/3;  //type casting 10/3=3.33
			if(avg>=95)
				grade='O';
			else if (avg>=70 && avg<95)
				grade='A';
			else if (avg>=60 && avg<75)
				grade='B';
			else
				grade='C';
		}
		else
			grade='F';
		System.out.println("Student Result");
		System.out.println("Student NO :"+sno);
		System.out.println("Student name :"+name);
		System.out.println("total marks "+tot);
		System.out.println("average marks "+avg);
		System.out.println("Grade "+grade);
	}

}
