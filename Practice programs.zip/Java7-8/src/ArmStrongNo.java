import java.util.Scanner;
public class ArmStrongNo {
public static void main(String[] args) {
// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter a no");
		int n=s.nextInt();
		int rem=0,arm=0;
		//assigning n value to temp variable
		int temp=n;
		while(n>0)
		{
			rem=n%10;
			arm=arm+rem*rem*rem;
			n=n/10;
		}
		if(temp==arm)
			System.out.println(temp+" is an Armstrong  no");
		else
			System.out.println(temp+" is not  an armstrong no");
	}

}


