import java.util.*;
public class Alphabet1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("Enter an alphabet");
		char c=s.next().charAt(0);
		//ascii value to char
		char x=(char)122;
		System.out.println("char value "+x);
		//ascii char to value
		int t=(int) c;
		System.out.println("ASCII  value "+t);
		//checking char is alphabet or not
		//if(c>=65 && c<=122)
		if(c>='A' && c<='z')
			System.out.println(c+ " is an alphabet");
		else
			System.out.println(c+ " is not an alphabet");
	}

}
