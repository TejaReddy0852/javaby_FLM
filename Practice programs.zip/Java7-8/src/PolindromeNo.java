//Polindrome no or not
import java.util.*;
public class PolindromeNo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int n,rem=0,rev=0;
			System.out.println("enter a no");
		 n=s.nextInt();
		//assigning n value to temp variable
		int temp=n;
		while(n>0)
		{
			rem=n%10;
			rev=rev* 10+ rem;
			n=n/10;
		}
		System.out.println("Reverse of the no ="+rev);
		if(temp==rev)
			System.out.println(temp+" is a polindrome no");
		else
			System.out.println(temp+" is not  a polindrome no");
	}
}
