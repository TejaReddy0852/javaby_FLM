//print multiplication tables of 1..10
public class MulTab110 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("multiplication tables from 1 to 10");
		for(int i=1;i<=10;i++) // i for table
		{
			System.out.println("table : "+i);
			for(int j=1;j<=10;j++)	//J FOR multiples
			{
				System.out.println(i+"  X   "+j +"   =  "+i*j);
			}
		System.out.println("");
		}
	}
}