import java.util.*;
public class Factorial {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter a no");
		int n=s.nextInt();
		int f=1,i=1;
			while(i<=n)			
			{
				f=f*i;
				i++;			
			}
		System.out.println("factorial value ="+f);
	}

}
