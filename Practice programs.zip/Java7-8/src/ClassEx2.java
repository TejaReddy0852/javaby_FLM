class Student
{
	int no,m1,m2,m3;
	String name;
	//receiving args from the method
	void accept(int n,String na,int x,int y,int z) 
	{
		System.out.println("receiving args from the obj");
		no=n;
		name=na;
		m1=x;
		m2=y;
		m3=z;
	}
	void display()
	{
		System.out.println("Student details");
		System.out.println("NO ="+no+ "  NAME ="+name);
		System.out.println("MATHS ="+m1+ " PHYSICS ="+m2+" COMPUTERS ="+m3);
		int tot=m1+m2+m3;
		double avg=tot/3;
		System.out.println("TOTAL ="+tot+"AVERAGE ="+avg);
	}
}
public class ClassEx2 {
	public static void main(String[] args) {
		//creating obj for Student 
		Student s=new Student();
		//calling methods of Student class
		s.accept(1001,"KISHORE", 98,87,33);
		s.display();
		//creating another obj
		Student s1=new Student();
		s1.accept(1002,"RAM", 66,32,78);
		s1.display();
	}
}