//creating a class
class Ex
{
	//member variables declarations
	int no;
	String name;
	//method definitions
	void input()
	{
		System.out.println("Ex -> input()");
	}
	void output()
	{
		System.out.println("Ex-> output()");
		System.out.println("no ="+no);
		System.out.println("name ="+name);
	}
}
public class ClassEx1 {
	public static void main(String[] args) {
		//creating object for Ex class
		Ex x=new Ex();
		
		//accessing members and methods
		x.no=102;
		x.name="KUMAR";
		x.input();
		x.output();
		
	}

}
