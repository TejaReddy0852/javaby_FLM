//WAP  to print the multiplication tables of Required nos
import java.util.*;
public class MulTabReqd {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s =new Scanner(System.in);
		int i,ch;
		do
		{
			System.out.println("enter a no");
			int n=s.nextInt();
			System.out.println("multiplication table of "+n);
			i=1;
				do 
				{
				System.out.println(n+ "   X  " +i+ "    =  "+(n*i));
					
					i++;
				}while(i<=10);
			System.out.println("want to continue(1/0)");
			ch=s.nextInt();
			
			}while(ch==1);
	}

}
