//printing ascii values and chars

public class WhileAscii {
	public static void main(String[] args) {
		
		int a=1;
		System.out.println("printing ASCII CHAR & value");
		char c;
		while(a<=255)
		{
			c=(char)a;
			System.out.print(c +"   "+ a);
			if(a%8==0)
				System.out.println();
			a++;
		}
	}

}
