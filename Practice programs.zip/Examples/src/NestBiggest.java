//finding biggest of 3 nos 
import java.util.*;
public class NestBiggest {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter 3 nos ");
		int a=s.nextInt();
		int b=s.nextInt();
		int c=s.nextInt();
		if(a>b)
		{
			if(a>c)
				System.out.println(a+ " is the biggest no");
			else
				System.out.println(c+ " is the biggest no");
		}
		else
		{
			if(b>c)
				System.out.println(b+ " is the biggest no");
			else
				System.out.println(c+ " is the biggest no");
		}
	}

}
