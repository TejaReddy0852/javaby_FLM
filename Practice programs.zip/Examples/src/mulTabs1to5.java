//multiplication tables from 1 to 5 in tabular format
public class mulTabs1to5 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for(int i=1;i<=5;i++)   // i for rows
		{
			for(int j=1;j<=5;j++)	// j for columns
			{
				System.out.print(i*j + "  ");
			}
			System.out.println();
			
		}
	}

}
