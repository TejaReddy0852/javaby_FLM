import java.util.*;
public class PrimeRange {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter min and max values to find prime nos");
		int min=s.nextInt();
		int max=s.nextInt();
		System.out.println("prime nos between "+min +" and  "+max);
		int i,c;
		for( ;min<=max ;min++)
		{
			for(i=1,c=0;i<=min/2;i++)
			{
				if(min%i==0)
					c++;
			}
			if(c==1)
				System.out.print(min+"   ");
		}
	}

}
