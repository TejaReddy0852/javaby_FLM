import java.util.*;
public class DoMenuChoice {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int t;
		do
		{
			System.out.println("Arithmetic Operations");
			System.out.println("1.Add");
			System.out.println("2.Sub");
			System.out.println("3.Mul");
			System.out.println("enter your choice(1/2/3) ");
			int ch=s.nextInt();
			System.out.println("enter 2 nos");
			int a=s.nextInt();
			int b=s.nextInt();
			switch(ch)
			{
			case 1: 
				System.out.println("Addition ="+(a+b));
				break;
			case 2: 
			System.out.println("Subtraction ="+(a-b));
			break;
			case 3: 
			System.out.println("Multiplication ="+(a*b));
			break;
			default:
			System.out.println("Wrong Choice");
			}
		System.out.println("want to continue(1/0");
		t=s.nextInt();
		}while(t==1);
		}

	}


