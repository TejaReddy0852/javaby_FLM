//print 1..10 nos
public class While1 {	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("printing nos from 1..10 ");
		int a=1;
		while(a<=10)
		{
				System.out.print("  "+ a);
				a++;
		}
		System.out.println("\nend");
}
}
