import java.util.*;
public class CharRornot {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter an alphabet");
		char c=s.next().charAt(0);
		
 		//check whether it is R or not
		if(c=='R' || c=='r')
		{
			System.out.println("entered char is R  "+c);
		}
		System.out.println("end");
	}

}
