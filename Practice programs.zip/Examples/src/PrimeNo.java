import java.util.*;
public class PrimeNo {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter a no");
		int n=s.nextInt();
		int i=1,count=0;
		//System.out.println("factors of "+n);
		while(i<=n)
		{
			if(n%i==0)
			{
				//System.out.print(i+"  ");
				count++;
			}
			i++;
		}
		if(count==2)
			System.out.println("\n"+n+" is a prime no");
		else
			System.out.println("\n"+n+" is not a  prime no");
	}
}
