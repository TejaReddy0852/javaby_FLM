import java.util.*;
public class ElseIfcolor {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter color char(r/g/b/w)");
		char c=s.next().charAt(0);
		if(c=='r'||  c=='R')
			System.out.println("RED");
		else if(c=='g'|| c=='G')
			System.out.println("GREEN");
		else if(c==98||  c==66)
		//else if(c=='b'|| c=='B')
			System.out.println("BLUE");
		else if(c=='w' || c=='W')
			System.out.println("WHITE");
		else
			System.out.println("Wrong choice");	
	}

}
