import java.util.Scanner;
public class BiggestElseif {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter 3 nos ");
		double a=s.nextDouble();
		double b=s.nextDouble();
		double c=s.nextDouble();
		if(a>b && a>c)
				System.out.println(a+ " is biggest no ");
		else if(b>a && b>c)
				System.out.println(b+ " is biggest no ");
		else
			System.out.println(c+" is biggest no");
		}
	}




