import java.util.*;
public class ReqdMulTables {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int choice,n,i;
		do
		{
			System.out.println("enter a no ");
			 n=s.nextInt();
			 i=1;
			do
			{
				System.out.println(n +"  X  "+i+"   = "+(n*i));
				i++;
			}while(i<=10);
			System.out.println("want to continue(1/0) =");
			choice=s.nextInt();
		}while(choice==1);

	}

}
