public class FormulTab {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	for(int i=1;i<=10;i++)   // i for tables
	{
		System.out.println("multiplication table of "+i);
		for(int j=1;j<=10;j++)	// j for multiples
			System.out.println(i +"   X   "+ j + "   = " + (i*j));
	}
}
}