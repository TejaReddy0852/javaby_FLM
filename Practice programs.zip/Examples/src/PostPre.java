public class PostPre {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=50;
		System.out.println("a ="+a);
		System.out.println("Post increment");
		System.out.println("a++ ="+a++);
		System.out.println("a ="+a);
		System.out.println("pre increment");
		System.out.println("++a ="+(++a));
		System.out.println("a ="+a);
		}

}
