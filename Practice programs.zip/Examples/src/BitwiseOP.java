
public class BitwiseOP {
public static void main(String args[])
{
	System.out.println("BITWISE OPERATORS");
	System.out.println("15 & 8=" +(15&8));
	System.out.println("15 | 8=" +(15 | 8));
	System.out.println("~-10 = "+(~-10));
	int x=5;
	int y=x<<3;		//101000
	System.out.println("left shift opeator 5<<3="+y);
	x=10;
	 y=x>>2;		//0010
	System.out.println("right shift opeator >>10="+y);
	}
}
