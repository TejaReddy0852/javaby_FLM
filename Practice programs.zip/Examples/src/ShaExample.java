
public class ShaExample {
public static void main(String args[])
{
	System.out.println("Short Hand Assignment operators ");
	int a=10,b=20;
	a+=b;		//a=a+b;
	System.out.println("a= a+b = "+a);
	System.out.println("a*=50 = "+(a*=50));  //a=a*50
}
}
