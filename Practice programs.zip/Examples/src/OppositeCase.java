import java.util.*;
public class OppositeCase {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter an alphabet :");
		char c=s.next().charAt(0);
		int t;
		if(c>=65 && c<=90)
			t=c+32;
		else
			t=c-32;
		
			c=(char)t;
		System.out.println("Alphabet in opposite case ="+c);
		t=(int)'T';
		System.out.println("T ascii value"+t);
	}

}
