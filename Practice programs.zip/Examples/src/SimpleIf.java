import java.util.*;
public class SimpleIf {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter a no");
		int a=s.nextInt();
		if(a>0)
		{
			System.out.println(a+"  is +ve no");
		}
		System.out.println("END");
	}
}
