//student result
import java.util.*;
public class ScannerEx {
public static void main(String args[]) {
	Scanner s=new Scanner(System.in);
	System.out.println("enter student no,name");
	int no=s.nextInt();
	String name=s.next();
	System.out.println("enter student marks in 3 subjects");
	int m1=s.nextInt();
	int m2=s.nextInt();
	int m3=s.nextInt();
	//calculating total,avg
	int tot=m1+m2+m3;
	double avg=(double)(tot/3);  // TYPE CASTING
	System.out.println("\t\t\t Student Result");
	System.out.println("Student NAME  = " +name);
	System.out.println("total marks= "+tot);
	System.out.println("average marks= "+avg);
	System.out.println("enter an alphabet ");
	char c=s.next().charAt(0);
	System.out.println("enterED  alphabet "+c);
	}
}
