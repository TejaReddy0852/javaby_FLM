import java.util.*;
public class LeapYear {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter a year");
		int t=s.nextInt();
		if(t%4==0 || t%100==0)
			System.out.println(t+"  is a leap year");
		else
			System.out.println(t+"  is not a leap year");
	}
}
