//do while example
public class DoWhile1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=100;
		System.out.println("printing 1..10 nos");
		do
		{
			System.out.println(a);
			a++;
		}while(a<=10);
		System.out.println("END");
	}

}
