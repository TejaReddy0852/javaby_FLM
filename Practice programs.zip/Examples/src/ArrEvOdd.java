import java.util.*;
public class ArrEvOdd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		int a[]=new int[5];
		System.out.println("enter 5 elements ");
		for(int i=0;i<5;i++)
			a[i]=s.nextInt();
		int esum=0,osum=0;
		for(int j:a)
		{
				if(j%2==0)
					esum=esum+j;
				else
					osum=osum+j;
		}
		System.out.println("even no sum ="+esum);
		System.out.println("ood no sum ="+osum);

	}

}
