//bigger no among  2 nos
import java.util.Scanner;
public class CondOper 
{
	public static void main(String args[])
	{
		Scanner s=new Scanner(System.in);
		System.out.println("enter 2 nos ");
		int a=s.nextInt();
		int b=s.nextInt();
		//bigger no
		int big=(a>b)? a : b;
		System.out.println("bigger no ="+big);
	}

}
