import java.util.Scanner;
public class SwitchColor {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter color char(r/g/b)");
		char c=s.next().charAt(0);
		System.out.println("entered char is "+c);
		switch(c)
		{
		case 'r':
		case 'R':
				System.out.println(c+" is red");
				break;
		case 'g':
		case 'G':
			System.out.println(c+" is green");
			break;
		case 98:
		case 66:
			System.out.println(c+" is BLUE");
			break;
		default:
			System.out.println("white");
		}
	}
}
	

