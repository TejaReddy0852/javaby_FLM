import java.util.*;
public class If2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter a number :");
		int n=s.nextInt();
				
		if(n>=100 && n<=200)
			System.out.println(n+ " Is between 100 to 200");
		else
			System.out.println(n+ "Is not between 100 to 200");
	}

}
