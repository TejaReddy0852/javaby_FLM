import java.util.*;

public class FactorialRange {

	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		
		int fact,j;
		
		System.out.println("factorial values from 1..10");
		for(int i=1;i<=10;i++)
		{
			System.out.println("factorial value of "+i);
			
			for( fact=1,j=1;j<=i;j++)	
			{
				fact=fact*j;
			}
			System.out.println(fact);
		}
	}

}
