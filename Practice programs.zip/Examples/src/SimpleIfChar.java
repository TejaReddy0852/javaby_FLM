import java.util.*;
public class SimpleIfChar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
	System.out.println("enter a alphabet");
			
	char c=s.next().charAt(0);   //to accept single char
	//checking the char is R or not
		if(c=='R' || c=='r')
			System.out.println(c+"   is R");
		
		System.out.println("end");
	}
}
