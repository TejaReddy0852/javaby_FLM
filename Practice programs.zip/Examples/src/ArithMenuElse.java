import java.util.*;
public class ArithMenuElse {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("\t\t\t Arithmetic Operations");
		System.out.println("1.Add\n2.Sub\n3.Mul ");
		
		System.out.println("enter your choice (1/2/3)");
		int ch=s.nextInt();
		
		System.out.println("enter 2 nos");
		int a=s.nextInt();
		int b=s.nextInt();
		
		if(ch==1)
			System.out.println("Addition of 2 nos ="+(a+b));
		else if(ch==2)
			System.out.println("substraction of 2 nos ="+(a-b));
		else if(ch==3)
			System.out.println("Multiplication of 2 nos ="+(a*b));
		else
			System.out.println("Reminder of 2 nos ="+(a%b));
		
	}

}
