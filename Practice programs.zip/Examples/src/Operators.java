
public class Operators {
	public static void main(String[] args) {
		System.out.println("Arithmatic Operators");
		System.out.println("addition 100+233 "+(100+233));
		System.out.println("Subtracion 1000-233 "+(1000-233));
		System.out.println("Multiplication 10*75 "+(10*75));
		System.out.println("Division 999/3 "+(999/3));
		System.out.println("Modulus 999%3 "+(999%3));
		}
}
