public class SwitchVowel {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char c='p';
		switch(c)
		{
		case 'a','A','e','E','i','I','o','O','u','U':
			System.out.println("vowel");
			break;
		default: 
			System.out.println("consonant");
		}
	}

}
