import java.util.*;
public class Big {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		System.out.println("enter 2 nos ");
		int a=s.nextInt();
		int b=s.nextInt();
		
		if(a>b)
		{
			System.out.println(a+ " is big ");
		}
		else
		{
			System.out.println(b+" is big");
		}
	}
	}


