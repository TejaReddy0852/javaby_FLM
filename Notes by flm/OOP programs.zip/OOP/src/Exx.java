class E
{
	static int a;
	static void disp()
	{
		a++;
		System.out.println(a);
	}
}
public class Exx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		E.disp();
		E.disp();
	}

}
