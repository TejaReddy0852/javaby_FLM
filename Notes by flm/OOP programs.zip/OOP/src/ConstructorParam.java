//default and parameterised constructors
class Empl
{
		int eno;
		String name;
		double basic;
		//default constructor
		Empl()
		{
			System.out.println("default constructor");
			eno=2000;
			name="abc";
			basic=60000;	
		}
		//constructor with args(parameterised)
		Empl(int no,String n,double sal)
		{
			System.out.println("parameterised constructor");
			eno=no;
			name=n;
			basic=sal;
		}
		void calc()
		{
			double hra=basic*0.12;// basic*12/100
			double da=basic *0.15;
			double ta=basic*0.12;
			double gsal=basic+hra+da+ta;
			System.out.println("employee basic salary ="+basic);
			System.out.println("HRA="+hra+"DA="+da+"TA="+ta);
			System.out.println("employee GROSS salary ="+gsal);
		}
		void print()
		{
			System.out.println("employee no ="+eno);
			System.out.println("employee name ="+name);
			calc();//calling nested method
		}
}
public class ConstructorParam {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Empl e=new Empl(1001,"ANIL",54000);//passing args to constructor
		e.print();
		Empl f=new Empl();
		f.print();
		
	}

}
