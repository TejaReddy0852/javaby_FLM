//single inheritance with this and super 
class Base1
{
	int a,b;
	Base1(int a,int b)	//base class constructor
	{
			
			System.out.println("Base class constructor");
			this.a=a;
			this.b=b;
	}
}
class Derive1 extends Base1
{
	int c;
	Derive1(int a,int b,int y)	//derive class constru
	{
		super(a,b);//calling super()
		System.out.println("Derive class constructor");		
		c=y;
		System.out.println("Derive1-> t = "+c);
	}
	void print()
	{
		int x=a+b+c; //accessing super class member
		System.out.println("Base -> a= "+a);
		System.out.println("Base -> b= "+b);
		System.out.println("Derive -> c= "+c);
		
		System.out.println("addition = "+x);
	}
}
public class SingleInheritance {

	public static void main(String[] args) {
		
		//creating obj for Derive class
		Derive1 d=new Derive1(100,200,300);
		d.print();
	}

}
