import arith.Add;
import arith.Mul;
import arith.Sub;

public class Test1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Add a=new Add(); //obj creation for Add
		Add.add();
		Sub s=new Sub();
		
		s.sub();
		Mul m=new Mul();
		int r=m.mul(40,4);
		System.out.println("multiplication ="+r);
		
		
	}

}
