class Example implements Runnable 
   {	
          public void run( )
            {
                for(int i=1; i<=10; i++)
                   {
                       System.out.println("Thread X :  "+i);
                    }
                System.out.println("End of Thread X " );
             }
   }
class RunnableTest
  {
       public static void main (String args[ ])	
           {
                 Example e = new Example( );
                 
                 Thread threadE =new Thread(e);
		   	    threadE.start();
			    System.out.println("End of main Thread");
             }
       		  }

