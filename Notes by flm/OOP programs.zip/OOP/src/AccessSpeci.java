class Emp
{
	int empno=101;
	 String name;
	 float sal;
	Emp(int eno,String n,float s)
	{
		empno=333;
		name=n;
		sal=s;
	}
	
	final void print()
	{
		System.out.println("employee details");
	System.out.println("emp no"+empno);
	System.out.println("emp name"+name);
	System.out.println("emp salary"+sal);
	}
}
class Emp1 extends Emp
{
	
	//accessing members of the class
	Emp1(int eno,String n,float s)
	{
		super(eno,n,s);
		empno=200;
		 sal=4000;
	}
	
	}


public class AccessSpeci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Emp e=new Emp(1001,"ABC",5000);
		e.empno=2004;
		e.sal=1000;
		
		e.print();
	}

}
