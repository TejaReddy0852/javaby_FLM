class ClassEx
{
		int a;
		double b;
		String s;
		//creating  Default Constructor
		ClassEx()
		{
			System.out.println("ClassEx() constructor calling");
			a=1;
			b=55.66;
			s=" a";
		}
		 void print()
		{
			System.out.println("values of the class");
			System.out.println("int ="+a+"   double = "+b+"string ="+s);
		}
}
class classEx2
{
	
}
public class ConstructorEx {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ClassEx x=new ClassEx(); //calling default constructor
		x.print();
			}

}
