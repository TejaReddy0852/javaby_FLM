import java.util.*;
class Cust
{
	int cno;
	String cname;
	double bal;
	Cust()
	{
		System.out.println("default constructor");
	}
	//param constructor
	Cust(int n,String na,double s)
	{
		System.out.println("Constructor with args(parameterised");
		cno=n;
		cname=na;
		bal=s;
	}
	void print()
	{
		System.out.println("CustDETAILS");
		System.out.println("cust no ="+cno + "\tname ="+cname);
		System.out.println("bill amt ="+bal);
		bal=bal+bal*0.05;		// 5/100=0.05
		System.out.println("bill amt with GST ="+bal);
	}
}
public class ClassArrObje {

	public static void main(String[] args) {
		// creating array of 3 objects 
		Cust e[]=new Cust[1000];
		Scanner s=new Scanner(System.in);
		System.out.println("Number of customers required ");
		int count=s.nextInt();
		int i;
		//accessing array of objects
		for( i=0;i<count;i++)
		{
		System.out.println("enter  cust no,name and bill amt");
			int a=s.nextInt();
			String b=s.next();
			double c=s.nextDouble();
			//sending args to the method
			System.out.println(i);
			e[i]=new Cust(a, b, c);
			
		}
		for( i=0;i<count;i++)
		{
			System.out.println((i+1)+" Customer details are");
				//calling print() 
			e[i].print();
		}
	}
}