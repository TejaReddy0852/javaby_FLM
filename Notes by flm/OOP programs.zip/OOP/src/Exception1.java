import java.lang.*;
public class Exception1 {
	public static void main(String[] args) {
		
		try
		{
			int x[]=new int[5];
			x[5]=20;
			int a=200;
			int b=a/10;
			System.out.println("b= "+b);	
		}
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
			System.out.println("please divide by non zero");
		}
		catch(ArrayIndexOutOfBoundsException e1)
		{
			
			System.out.println(e1.getMessage());
			System.out.println("you are approaching out of index ");
		}
		finally
		{
			System.out.println("come back again....");
		}
	}

}
