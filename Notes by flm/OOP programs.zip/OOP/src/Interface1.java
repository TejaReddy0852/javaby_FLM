interface XS
{
	void input();
}
interface AAA 
{
	 int max_mark=100;
	public void show() ;
}
//achieving multiple inheritance	
class Inter1   implements AAA,XS  
{
		int a;
		void check()
		{
			System.out.println("class ->check");
		}
	public void show()  //interface AAA method
	{
		System.out.println("interface A -> show()");
	}
	public void input()	// interface X method
	{
		System.out.println("Inter1 class ->interface x-> input()");
	}
}
	public class Interface1
	{
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Inter1 i=new Inter1();
		i.check();
		i.show();
		i.input();
	}

}
