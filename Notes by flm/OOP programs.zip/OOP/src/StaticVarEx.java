import java.util.
class StaticEx
{
	 static int count=10;
	static void static_fun()
	{	
		int a=10;
		count++;
		a++;
		System.out.println("count ="+count);
		System.out.println("a ="+a);
	}
	static void print()
	{
		System.out.println("print() ");
	}
}
public class StaticVarEx {
	public static void main(String[] args) {
		//calling
		StaticEx.static_fun();
		StaticEx.static_fun();
		StaticEx.static_fun();
		StaticEx.print();
		StaticEx y=new StaticEx();
		y.print();
		
		//some of the predefined static methods
		int a=Math.abs(-444);
		System.out.println("abs(-444) ="+a);
		System.out.println("pow(5,4)=" +Math.pow(5, 4));
			
		}
		
		
	}


