import java.util.*;
class Test
{
	 int c;
	Scanner s=new Scanner(System.in);
	int power()
	{
		System.out.println("enter a no and power");
		 c=s.nextInt();
		int t=s.nextInt();
		 int r=1;
			for(int j=1;j<=t;j++)
				r=r*c;
			System.out.println(c+ " to the power of  " +t );
			return(r);
	}
	void power(int a,int i)
	{
		 int r=1;
		for(int j=1;j<=i;j++)
			r=r*a;
		System.out.println(a+ " to the power of  " +i );
		System.out.println(r);
	}
}
public class MethodOL2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Scanner s=new Scanner(System.in);
			System.out.println("enter a no and its power value");
			int n=s.nextInt();
			int t=s.nextInt();
				
			Test x=new Test();
			x.power(n,t);	// with args
			int e=x.power();	//without args with return value
			System.out.println(e);
	}
}
