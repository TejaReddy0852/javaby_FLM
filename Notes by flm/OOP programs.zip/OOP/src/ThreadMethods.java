import java.lang.*;
class AA extends Thread
  {
      public void run( )
        {
              for (int i= 1; i<=5; i++)
   		  {
            	  if(i==2)
            		  suspend();
                  System.out.println("From Thread A :  i= " +i);
                  if (i==4)
                	  resume();
                    
          	  }
              
              System.out. println("Exit from A..");
         }
 	   }
    class BB extends Thread 
    {
         public void run( )
            {
                  for(int j=1;j<=5; j++)
                  {
                	  System.out.println("From Thread B : j =" + j); 
                	  if(j==3)      stop();
                  }
                  System.out.println("Exit from B..");
              }
  	     }
class C extends Thread 
    {
          public void run( )
            {
                for(int k=1;k<=5; k++)
    {
              System.out.println("From Thread C : k =" + k); 
              if(k==1)
                   try 
                     {
                            sleep(1000);
                      } 
                     catch( Exception e)
 	                        {
                         }
             }
       System.out.println("Exit from C..");
               }
        }
  class ThreadMethods
   {
      public static void main(String args[]) 
      {
             AA  a =new AA( );
             BB  b=new BB( );
             C  c=new C( );
             System.out.println( "Start thread A"); 
             a.start( );
             System.out.println( "Start thread B");
             b.start( );
             System.out.println( "Start thread C");
             c.start( );
             System.out.println("End of main thread");
       }
 }

