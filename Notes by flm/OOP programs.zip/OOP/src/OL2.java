class Method2
{
	void print()
	{
		System.out.println("________________________");
	}
	void print(int x)
	{
		System.out.println("arg ="+x);
		System.out.println("Square of the int no ="+(x*x));
	}
	void print(String s1,String s2,String s3)
	{
		System.out.println("print() with 3 string args");
		System.out.println("first arg ="+s1);
		System.out.println("second arg ="+s2);
		System.out.println("third arg ="+s3);
		String t=s1+s2+s3;
		System.out.println("concatenation ="+t);
	}
	double print(double p,double q)
	{
		System.out.println("print() with 2 double values");
		System.out.println("first arg ="+p);
		System.out.println("second arg ="+q);
		return(p*q);
	}
}
public class OL2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			Method2 m=new Method2();
			m.print();
			m.print(100);
			double x=m.print(3445.66,6554.343);
			System.out.println("multiplication of 2 double "+x);
			m.print("FRONT","LINES","MEDIA");
	}

}
