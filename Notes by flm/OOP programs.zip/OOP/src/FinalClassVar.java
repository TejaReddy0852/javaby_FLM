 class A
{
	int x;// friendly
	A(int p)
	{
			x=p;
	}
	void disp()
	{
		System.out.println("x ="+x);
	}
}
 class B extends A
{
	final int y=50;
	B(int p)
	{
		super(p);
	}
	void disp()
	{
		x=33;
		//y=51; //cannot be assigned final vars
			System.out.println("y ="+y);
	}
	@Override
	protected void finalize() throws Throwable {
		// TODO Auto-generated method stub
		super.finalize();//destructor AGC
		{
		}
	}
 }

public class FinalClassVar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		B t=new B(100);
		t.disp();
	t.x=200;
	System.out.println(t.y);
	
	}

}
