class Method1
{
	void add() //add() without args & without return value
	{
		int a=100,b=400;
		System.out.println("add() without args & without return value");
		System.out.println("addition of 2 nos "+(a+b));
	}
	int add(int a,int b)
	{
		System.out.println("add() with 2 args & with int return value");
		System.out.println(a+"   "+b);
		return(a+b);
	}
	double add(double x,double y,double z)
	{
		System.out.println("add() with 3 double args & return value");
		System.out.println(x+"   "+y+"   "+z);
		return(x+y+z);
	}
}
public class MethodOveloading {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Method1 m=new Method1();
		//calling add()
		m.add();
		
		int t=m.add(44,66);
		System.out.println("addition of 2 ints ="+t);
		//calling add() with 2 args
		t=m.add(333,57787);
		System.out.println("addition of 2 ints ="+t);
		double d=m.add(445.777,5788.343,66887.5454);
		System.out.println("addition of 3 double ="+d);
		double d1=m.add(4,5,6);
		System.out.println("addition of 3 double ="+d1);
		}

}
