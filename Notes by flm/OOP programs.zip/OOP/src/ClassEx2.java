//creating class methods and sending args
import java.util.*;
class Ex2
{	//data members
	 int no;
	 String name;
	 String cname="Java";
	 Ex2(){}
	//methods definition
	void input(int n,String na)		//sending values to input()
	{
		System.out.println("receiving args from the object");
		no=n;			//assigning args to member variables
		name=na;
	}
	void display()
	{
		System.out.println("member values of the object");
		System.out.println(" no = "+no +"   \n name= "+name);
		System.out.println("COURSE NAME="+cname);
	}
	void check(int a)
	{
		if(a%2==0)
				System.out.println(a+"  even no");
		else
				System.out.println(a+"  odd no");
	}
}
public class ClassEx2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		Ex2 t=new Ex2();
		
		//calling methods of Ex2 with args
		t.input(1001,"FRONT LINES");
		t.display();
		t.check(123);
		//creating another object and calling methods
		//with runtime values
		Ex2 y=new Ex2();
		//calling methods of Ex2 with args
		System.out.println("enter no and name");
		int p=s.nextInt();
		String n=s.next();
		//passing values as args to obj method
		y.input(p,n);
		y.display();
		System.out.println("enter a no");
		y.check(s.nextInt());
		}
}
