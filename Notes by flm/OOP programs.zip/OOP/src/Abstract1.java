abstract class Exx
  {
	 int  pno;//by default friendly
	  String  pna;
    abstract void  putdata ();
    void  putPerson ()
      {
        System.out.println ( "\n Person Number : "+pno );
        System.out.println ( "\n Person Name  :  "+pna );
      }
  }
  class  Student1 extends  Exx
  {
    int  m1, m2;
     int tot=100;
    Student1 ( int  pno, String  pna, int  m1, int  m2 )
      {
        this.pno = pno;
        this.pna = pna;
        this.m1 = m1;
        this.m2 = m2;
      }
    	void  putdata ( )  //inherited method
      {
        tot = m1 + m2;
        System.out.println ( "\n Student Number  :  "+pno );
        System.out.println ( "\n Student Name  :  "+pna );
        System.out.println ( "\n Marks  :  "+m1+"   "+m2 );
        System.out.println ( "\n Total  :  "+tot );
      }
    void  putResult ( )
      {
        double  avg = ( double )tot/2;
        String  res = "";
        if ( avg > 75 )
          res = "Distinction";
        else  if ( avg > 60 )
          res = "I class";
        else  if ( avg > 50 )
          res = "II class";
        else if ( avg > 35 )
          res =  "III class";
        else
          res = "Fail";
        System.out.println ( "\n Result  :  "+res );
      }
  } 
class  Abstract1
  {
   public  static  void  main ( String  args [ ] )
      {
	 //Exx a=new Exx(); //not possible
    	Student1  S = new  Student1 ( 101, "Praveen", 90, 95 );
     // Super class instance can refer to sub class instance
        Exx  P = S;
        P.putdata ( );
        S.putResult ( );
        S.putPerson();
        
     }
  }

