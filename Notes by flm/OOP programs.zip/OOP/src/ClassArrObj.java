import java.util.*;
class Stu
{
	int no;
	String name;
	Stu(int n,String na)  	//param constructor
	{
		System.out.println("Stu() constructor");
		no=n;
		name=na;
	}
	void write()
	{
		System.out.println("Student class members");
		System.out.println("sno = "+no+"name ="+name);
	}
}
public class ClassArrObj {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Stu s[] =new Stu[5];
		int i;
		Scanner sc=new Scanner(System.in);
		for(i=0;i<3;i++)
		{
			//accepting values at runtime and sending to method
			System.out.println("enter sno,name ");
				int sno=sc.nextInt();
				String t=sc.next();
			//calling each obj constructor
						s[i]=new Stu(sno,t);
		}
		
		System.out.println("Student details");
		for(i=0;i<3;i++)
			s[i].write();
		
	}

}
