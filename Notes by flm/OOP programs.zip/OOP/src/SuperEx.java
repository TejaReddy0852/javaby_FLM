class Base
{
		int a;
		Base()
		{
				System.out.println("Base class Constructor");
			//	a=x;
		}
	}
class Derive extends Base
{
	int b;
		Derive()
		{
			super();
			System.out.println("Derive class constructor");
			
			

		}
		void disp()
		{
			System.out.println("Base and Derive members");
			System.out.println("a ="+a+"\t b=    "+b);
		}
}
public class SuperEx {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Derive d=new Derive();
		d.disp();
	}
}
