import java.lang.*;
public class MultipleException {
	public static void main(String[] args) {
		int a=10,b=02;
		try
		{
			double d[]=new double[3];
			d[0]=4899;
			d[1]=6778;
			d[2]=111;
			
			int x=a/b;
		}
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
		}
		catch(ArrayIndexOutOfBoundsException f)
		{
			System.out.println(f.getMessage());
		}
		catch(Exception t)
		{
			System.out.println(t.getMessage());
		}
		finally
		{
			System.out.println("END");
		}

	}

}
