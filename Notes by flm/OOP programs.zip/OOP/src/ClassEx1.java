class Stud
	{
		int no;
		String name,cls;
		 void accept()
		{
			System.out.println("Student- > accept() ");
			//accessing class members
			no=101;
			name="abc";
			cls="B.TECH";
		}
		void print( )
		{
		System.out.println("Student ->print( ) ");
		System.out.println("no ="+no+ " name  ="+name+" class ="+cls);
		}
	}
public class ClassEx1{
	public static void main(String[] args) {
		Stud x=new Stud( );	//instantiation	
		x.print();
		//METHODS calling
		x.accept();
		x.print();
		}

}
