package arith;
import arith.*;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//Add a=new Add(); //obj creation for Add
		Add.add();
		Sub s=new Sub();
		
		s.sub();
		Mul m=new Mul();
		int r=m.mul(40,4);
		System.out.println("multiplication ="+r);
		
		
	}

}
