package arith;

public class SingleInheriConstr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
