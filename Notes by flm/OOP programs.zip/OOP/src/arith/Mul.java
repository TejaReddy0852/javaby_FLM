package arith;

public class Mul {
	public int mul(int x,int y)
	{
		System.out.println("Mul class mul() with args");
		System.out.println("first arg ="+x+ "  second arg ="+y);
		return(x*y);
	}
}
