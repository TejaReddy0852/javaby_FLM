package arith;
public class Add {
	public static void add()
	{
		int a=200,b=400;
		System.out.println("addition of 2 nos ="+(a+b));
	}
}

	

