package arith;

public class Sub {
		public void sub()
		{
			int a=600,b=100;
			System.out.println("substraction of 2 nos ="+(a-b));
		}
	}


