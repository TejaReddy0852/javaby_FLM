class One
{
	  int a;// friendly
	 One(int a) 
     {
		System.out.println("One -> class Constructor( )");
		this.a=a;
	}
	void check() {
		System.out.println("check()");
	}
}
class Two extends One {
	int b ;
	Two(int a, int b) 
	{
		super(a);
		System.out.println("Two -> class Constructor( )");
		this.b = b;
	}
	void print()
	{
			System.out.println("Two ->print()");
	}
}
class Three extends Two
{
	 int c;
	Three(int a, int b, int c) {
		super(a, b); // sends values to Two class
		this.c = c;
		System.out.println("Three class Constructor");
	}
	void calc() {
		System.out.println("One class a=" + a);
		System.out.println("Two class b=" + b);
		System.out.println("Three class c=" + c);
		print();//calling base class method
		int d = a + b + c;// accessing One ,Two class members
		System.out.println("addition of 3 class members " + d);
	}
}
public class MultiLevel {
	public static void main(String[] args) {
		// creating obj for Third class
		Three t = new Three(10, 30, 40);
		t.check();//One class method
		t.calc();// Three class method
	}
}
