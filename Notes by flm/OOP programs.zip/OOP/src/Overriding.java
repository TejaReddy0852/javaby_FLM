class Bas
{
	int a;
	Bas(int x)
	{
		a=x;
		System.out.println("Base class Constructor");
	}
	void print()
	{
		System.out.println("Base class print(), a="+a);
	}
}
class Derived extends Bas
{
	int b;
	Derived(int x,int y)
	{
		super(x);//sending 1st arg to super class
		System.out.println("Derived class Constructor");
		b=y;
	}
	void print()		//OVERRIDING
	{
		System.out.println("Derive class print(), b="+b);
	}
}
public class Overriding 
{

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Derived d=new Derived(10,20);
		d.print();
	}
}
