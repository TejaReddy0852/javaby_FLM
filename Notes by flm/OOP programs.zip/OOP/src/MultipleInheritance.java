import java.util.Scanner;
class Stu1
{
	int sno;
	String name,course;
	void input(int no,String n,String c)
	{
		System.out.println("Student(c) -> input()");
		sno=no;
		name=n;
		course=c;
	}
	void output()
	{
		System.out.println("Student no ="+sno);
		System.out.println("Student name ="+name);
		System.out.println("Student course ="+course);
	}
}
class Exam extends Stu1
{
	int m1,m2,m3;
	void read(int x,int y,int z)
	{
		System.out.println("Exam ->read()");
		m1=x;
		m2=y;
		m3=z;
	}
	void write()
	{
		System.out.println("Student marks");
		System.out.println("computer ="+m1);
		System.out.println("Maths ="+m2);
		System.out.println("Electronics ="+m3);
	}
}
//creating interface
interface Sports
{
	  int sp=7;
	 public void get_sm();
}
//multiple inheritance
class Result extends Exam implements Sports
{
	//defining get_sm() of Sports interface
	 public void get_sm()
	{
			System.out.println("Sports(I) -> get_sm() ");
	}
	void display()
	{
		//calling Student class output()
		output();	//calling nested methods
		write();
		System.out.println("sports marks ="+sp);
		int tot=m1+m2+m3+sp; //marks from Exam class+Sports
		System.out.println("Total marks = "+tot);
	}
}
public class MultipleInheritance {

	public static void main(String[] args) {
		// creating obj for Result class
		Result r=new Result();
		Scanner s=new Scanner(System.in);
		System.out.println("enter sno,name and course");
		int n=s.nextInt();
		String na=s.next();
		String co=s.next();
		System.out.println("enter 3 subject marks ");
		int a=s.nextInt();
		int b=s.nextInt();
		int c=s.nextInt();
		r.input(n,na,co);
		r.read(a,b,c);
		r.get_sm();
		r.display();
	}

}
