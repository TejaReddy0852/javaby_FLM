import java.lang.*;
 class Ex1 extends Thread
 {
	 public void run()
	 {
		 System.out.println("printing 1 to 5 numbers");
		 for(int i=1;i<=5;i++)
			 System.out.println("Ex1->   "+i);
		 
		 		 System.out.println("end of Ex1 Thread");
	 }
 }
 class Ex3 extends Thread
 {
	 public void run()
	 {
		 System.out.println("printing 50 to 55 numbers");
		 for(int i=51;i<=55;i++)
			 System.out.println("Ex3->   "+i);
		 System.out.println("end of Ex3 Thread");
	 }
 }
public class ThreadEx {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//creating obj for Thread Classes
		Ex1 x=new Ex1();
		Ex3 y=new Ex3();
		//executing threads
		y.setPriority(3);
		x.start();
		y.start();
		//thread priorities
	x.setPriority(Thread.NORM_PRIORITY);
	System.out.println(x.getPriority());
		

		
	}

}
