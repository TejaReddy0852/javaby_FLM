class A1	//super class
{
	A1()
	{
		System.out.println("A constructor");
	}
	 void disp_A()
	{
		System.out.println("A -> disp_A()");
	}
}
class B1 extends A1
{
		B1()
		{
			System.out.println("B class connstructor");
		}
	void disp_B()
	{
		System.out.println("B -> disp_B()");
	}
}
class C1 extends A1
{
	C1()
	{
		System.out.println("C1 Constructor");
	}
	void disp_C()
	{
		System.out.println("C -> disp_C()");	
	}
}
class D extends C1
{
	D()		//creating default constru
	{
		System.out.println("D class constructor");
	}
	void disp_D()
	{
		System.out.println("D -> disp_D()");
	}
}
public class Hierarchy {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		D x=new D();
		x.disp_A();
		x.disp_C();
		x.disp_D();
		
	}

}
