//single inheritance
class Bas1
{
	void show()
	{
		System.out.println("Base -> show()");
	}
}
class Deri extends Bas1
{
		void print()
		{
			System.out.println("Derive -> print()");
		}
}
public class SingleInheEx {
	public static void main(String[] args) {
		
		//creating obj for Derive class
		Deri d=new Deri();
		
		//accessing Base class method
		d.show();
		//accessing Derive class method
		d.print();
	}

}
