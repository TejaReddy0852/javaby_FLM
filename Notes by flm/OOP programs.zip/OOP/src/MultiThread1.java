class Thread1 extends Thread
{
	 public void run()
	{
		System.out.println("Thread1 prints 1..5");
		for(int i=1;i<=5;i++)
		{
			System.out.println("print i  values of Thread1 "+i);
		}
	}
}
class Thread2 extends Thread
{
	public void run()
	{
		System.out.println("Thread2 prints 10..6");
		for(int j=10;j>=6;j--)
		{
			System.out.println("print j  values of Thread2 "+j);
			
		}
	}
}
public class MultiThread1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Thread1 t=new Thread1();
		Thread2 s=new Thread2();
		t.start();
		s.start();
		System.out.println("thread1 priority ="+t.getPriority());
		s.setPriority(t.getPriority()-1);
		System.out.println("thread 2 priority="+s.getPriority());
		
	}

}
